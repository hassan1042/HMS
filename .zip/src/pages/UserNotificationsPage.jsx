import React from 'react'
import UserNotifications from '../components/user-notifications/UserNotifications'

function UserNotificationsPage() {
  return (
    <div>
      <UserNotifications/>
    </div>
  )
}

export default UserNotificationsPage
