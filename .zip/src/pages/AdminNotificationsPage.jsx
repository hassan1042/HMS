import React from 'react'
import AdminNotifications from '../components/admin-notifications/AdminNotifications'

function AdminNotificationsPage() {
  return (
    <div>
      <AdminNotifications/>
    </div>
  )
}

export default AdminNotificationsPage
