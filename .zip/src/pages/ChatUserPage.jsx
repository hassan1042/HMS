import React from 'react'
import UserChat from '../components/chat/UserChat'

function ChatUserPage() {
  return (
    <div>
      <UserChat/>
    </div>
  )
}

export default ChatUserPage
