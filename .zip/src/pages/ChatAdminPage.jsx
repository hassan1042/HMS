import React from 'react'
import AdminChat from '../components/chat/AdminChat'

function ChatAdminPage() {
  return (
    <div>
      <AdminChat/>
    </div>
  )
}

export default ChatAdminPage
