import React from 'react'
import AdminRecords from '../components/admin/AdminRecords'

function AdminRecordsPage() {
  return <AdminRecords/>
}

export default AdminRecordsPage
