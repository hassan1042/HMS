import React from 'react'
import FoodOrderMain from '../components/food-order/Index'

function FoodOrder() {
  return (
    <div>
      <FoodOrderMain/>
    </div>
  )
}

export default FoodOrder
