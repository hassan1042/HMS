import React from 'react';

const NotFound = () => <h1 className="text-2xl">Page Not Found</h1>;

export default NotFound;
