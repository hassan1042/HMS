import React from 'react'
import RentalMain from '../components/rental/Index'

function Rental() {
  return (
    <div>
      <RentalMain/>
    </div>
  )
}

export default Rental
