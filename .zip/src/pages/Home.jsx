import React from 'react'
import HomeMain from '../components/home/Index'

function Home() {
  return (
    <div>
      <HomeMain/>
    </div>
  )
}

export default Home
