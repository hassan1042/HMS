import React from 'react'
import Reports from '../components/reports/Reports'

function ReportsPage() {
  return (
    <div>
      <Reports/>
    </div>
  )
}

export default ReportsPage
