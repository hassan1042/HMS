import React from 'react'
import RegistrationTabs from '../components/registrations/Tabs'

function RegistrationPage() {
  return (
    <div>
      <RegistrationTabs/>
    </div>
  )
}

export default RegistrationPage
