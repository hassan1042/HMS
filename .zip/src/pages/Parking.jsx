import React from 'react'
import ParkingMain from '../components/paking/Index'

function Parking() {
  return (
    <div>
      <ParkingMain/>
    </div>
  )
}

export default Parking
