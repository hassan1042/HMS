import React from 'react'
import WeddingHalls from '../components/wedding-hall/WeddingHalls'

function WeddingHallsPage() {
  return (
    <div>
      <WeddingHalls/>
    </div>
  )
}

export default WeddingHallsPage
