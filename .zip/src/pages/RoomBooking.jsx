import React from 'react'
import RoomBookingMain from '../components/room-booking/Index'

function RoomBooking() {
  return (
    <div>
      <RoomBookingMain/>
    </div>
  )
}

export default RoomBooking
