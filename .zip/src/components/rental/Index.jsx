import React from 'react';
import VehicleRentalPage from './VehicalRental';

const RentalMain = () => <VehicleRentalPage/>

export default RentalMain;
